import React from 'react';
import ReactDOM from 'react-dom';
import {Router,Route,Link,IndexRoute,hashHistory,IndexLink,browserHistory }from 'react-router'
import { createStore } from 'redux'
import { Provider } from 'react-redux'

import finalCreateStore from '../app/redux/index.jsx'

var App = React.createClass({
	getInitialState() {
		return{
			name:"测试中文",
			url:"shows/"+(5+1)
		}
	},
	handleSubmit(event) {
		alert("username是"+event.target.elements[0].value+"  "+ " repo是"+event.target.elements[1].value)
		browserHistory.push("/shows/12")
	},
   render() {

       return(
      <div>首页
      <div>
     <form onSubmit={this.handleSubmit}>
 	 	<input type="text" placeholder="userName"/>
  		<input type="text" placeholder="repo"/>
 	 	<button type="submit">Go</button></form>
      <IndexLink to="/">首页</IndexLink>
      <Link to="tv">链接1</Link>
      <Link to={{ pathname: this.state.url, query: { name: this.state.name } }}>
  链接2
</Link>
      </div>
       {this.props.children}
     </div>
    
      )
     }
	

});



/*class App extends React.Component{
  constructor(props) {
    super(props);
    console.log(this.props.location)
  }

   render() {
       return(
      <div>首页
      <div>
      <IndexLink to="/">首页</IndexLink>
      <Link to="tv">链接1</Link>
      <Link to={{ pathname: 'shows/12', query: { name: 'ryan' } }}>
  链接2
</Link>
      </div>
       {this.props.children}
     </div>
    
      )
     }
}*/



var TV = React.createClass({

	render() {
    return(<div>这是链接1</div>)
  }

});




var Show = React.createClass({


  render() {
  	console.log(this.props.location.query)
    return(<div>这是链接2{this.props.params.id}</div>)
  }

});







var Home = React.createClass({

	render() {
    return(<div>这是home页面</div>)
  }

});


function showsEnter (){
  	console.log("进入了")

}


ReactDOM.render(
    (
     <Router history={hashHistory}>
     
    <Route path="/" component={App}>
    <IndexRoute  component={Home}/>
    <Route path="tv" component={TV}>
    
    </Route>
    <Route path="shows/:id" component={Show} onEnter={showsEnter} >
        </Route>
    </Route>

    </Router>), document.getElementById("home")
    )

    
