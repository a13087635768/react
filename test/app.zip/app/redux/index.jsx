import React from 'react';
import ReactDOM from 'react-dom';
import {Router,Route,Link,IndexRoute,hashHistory,IndexLink,browserHistory }from 'react-router'
import { createStore } from 'redux'
import { Provider } from 'react-redux'


//reducer方法
var reducer=function(state,action){
	switch ((action.type)){
		case "add_todo":return state.concat(action.text);
		default:return state


	}


}


var store = redux.createStore(reducer, []);	